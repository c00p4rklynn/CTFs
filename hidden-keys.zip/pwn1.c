#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

void flag(int Password)
{
	FILE *fptr;
	char c;
	fptr = fopen("flag.txt", "r");
	 
	if (Password == 0xaf45903d) {
		if (fptr == NULL) 
    	{ 
    	    printf("Cannot open file \n"); 
    	    exit(0); 
    	} 
  	
    	c = fgetc(fptr); 
	
    	while (c != EOF) 
    	{ 
    	    printf ("%c", c); 
    	    c = fgetc(fptr); 
    	} 
  	
    	fclose(fptr);
		}
	else
	{
		puts("We dont want newbies playing around us here...");
	}
	exit(1);
}

int main(int argc, char **argv)
{
	volatile int key;
	key = 0;
	char buffer[64];
	gets(buffer);

	if ( key == 0xb348aef3) {
		puts("Oh so you got the key. Gimme a ROP3 to get the flag");
	}
	else
	{
		puts("Pwn harder... :)");
		exit(0);
	}

}
